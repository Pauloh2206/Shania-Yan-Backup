export default async function menuadm(prefix, botName = "MeuBot", userName = "Usuário", {
    header = `╭┈⊰ 🌸 『 *${botName}* 』\n┊Olá, #user#!\n╰─┈┈┈┈┈◜❁◞┈┈┈┈┈─╯`,
    menuTopBorder = "╭┈",
    bottomBorder = "╰─┈┈┈┈┈◜❁◞┈┈┈┈┈─╯",
    menuTitleIcon = "🍧ฺꕸ▸",
    menuItemIcon = "•.̇𖥨֗🍓⭟",
    separatorIcon = "❁",
    middleBorder = "┊",
    adminMenuTitle = "🛡️ GESTÃO DE USUÁRIOS",
    managementMenuTitle = "💬 GESTÃO DO GRUPO",
    securityMenuTitle = "🔒 SEGURANÇA",
    moderatorsMenuTitle = "👥 MODERADORES",
    partnershipsMenuTitle = "🤝 PARCERIAS",
    activationsMenuTitle = "⚡ ATIVAÇÕES",
    settingsMenuTitle = "🎨 CONFIGURAÇÕES"
} = {}) {
    const formattedHeader = header.replace(/#user#/g, userName);
    return `‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎
${formattedHeader}

${menuTopBorder}${separatorIcon} *${adminMenuTitle}*
${middleBorder}
	${middleBorder}${menuItemIcon}${prefix}abrirgp
	${middleBorder}${menuItemIcon}${prefix}addblacklist
	${middleBorder}${menuItemIcon}${prefix}addmod
	${middleBorder}${menuItemIcon}${prefix}addmodcmd
	${middleBorder}${menuItemIcon}${prefix}addparceria
	${middleBorder}${menuItemIcon}${prefix}addpartnership
	${middleBorder}${menuItemIcon}${prefix}addregra
	${middleBorder}${menuItemIcon}${prefix}addrule
	${middleBorder}${menuItemIcon}${prefix}adv
	${middleBorder}${menuItemIcon}${prefix}advertir
	${middleBorder}${menuItemIcon}${prefix}antibotao
	${middleBorder}${menuItemIcon}${prefix}antibtn
	${middleBorder}${menuItemIcon}${prefix}antidelete
	${middleBorder}${menuItemIcon}${prefix}antidoc
	${middleBorder}${menuItemIcon}${prefix}antifig
	${middleBorder}${menuItemIcon}${prefix}antiflood
	${middleBorder}${menuItemIcon}${prefix}antigore
	${middleBorder}${menuItemIcon}${prefix}antilinkgp
	${middleBorder}${menuItemIcon}${prefix}antilinkhard
	${middleBorder}${menuItemIcon}${prefix}antiloc
	${middleBorder}${menuItemIcon}${prefix}antiporn
	${middleBorder}${menuItemIcon}${prefix}antispamcmd
	${middleBorder}${menuItemIcon}${prefix}antistatus
	${middleBorder}${menuItemIcon}${prefix}autocleanup
	${middleBorder}${menuItemIcon}${prefix}autodl
	${middleBorder}${menuItemIcon}${prefix}autodown
	${middleBorder}${menuItemIcon}${prefix}automsg
	${middleBorder}${menuItemIcon}${prefix}autoresposta
	${middleBorder}${menuItemIcon}${prefix}autorespostas
	${middleBorder}${menuItemIcon}${prefix}autosticker
	${middleBorder}${menuItemIcon}${prefix}ban
	${middleBorder}${menuItemIcon}${prefix}banghost
	${middleBorder}${menuItemIcon}${prefix}bangp
	${middleBorder}${menuItemIcon}${prefix}banir
	${middleBorder}${menuItemIcon}${prefix}bemvindo
	${middleBorder}${menuItemIcon}${prefix}blacklist
	${middleBorder}${menuItemIcon}${prefix}blockcmd
	${middleBorder}${menuItemIcon}${prefix}bv
	${middleBorder}${menuItemIcon}${prefix}cita
	${middleBorder}${menuItemIcon}${prefix}clean
	${middleBorder}${menuItemIcon}${prefix}cleanup
	${middleBorder}${menuItemIcon}${prefix}closegp
	${middleBorder}${menuItemIcon}${prefix}configsaida
	${middleBorder}${menuItemIcon}${prefix}delblacklist
	${middleBorder}${menuItemIcon}${prefix}delfotobv
	${middleBorder}${menuItemIcon}${prefix}delfotosaiu
	${middleBorder}${menuItemIcon}${prefix}dellimitmessage
	${middleBorder}${menuItemIcon}${prefix}delmod
	${middleBorder}${menuItemIcon}${prefix}delmodcmd
	${middleBorder}${menuItemIcon}${prefix}delparceria
	${middleBorder}${menuItemIcon}${prefix}delpartnership
	${middleBorder}${menuItemIcon}${prefix}delregra
	${middleBorder}${menuItemIcon}${prefix}delrule
	${middleBorder}${menuItemIcon}${prefix}demote
	${middleBorder}${menuItemIcon}${prefix}desbangp
	${middleBorder}${menuItemIcon}${prefix}desmutar
	${middleBorder}${menuItemIcon}${prefix}desmute
	${middleBorder}${menuItemIcon}${prefix}div
	${middleBorder}${menuItemIcon}${prefix}divulgar
	${middleBorder}${menuItemIcon}${prefix}exitimg
	${middleBorder}${menuItemIcon}${prefix}exitmsg
	${middleBorder}${menuItemIcon}${prefix}fotobv
	${middleBorder}${menuItemIcon}${prefix}fotosaida
	${middleBorder}${menuItemIcon}${prefix}fotosaiu
	${middleBorder}${menuItemIcon}${prefix}gamemode
	${middleBorder}${menuItemIcon}${prefix}grantmodcmd
	${middleBorder}${menuItemIcon}${prefix}group
	${middleBorder}${menuItemIcon}${prefix}grupo
	${middleBorder}${menuItemIcon}${prefix}hidetag
	${middleBorder}${menuItemIcon}${prefix}imgsaiu
	${middleBorder}${menuItemIcon}${prefix}kick
	${middleBorder}${menuItemIcon}${prefix}legendabv
	${middleBorder}${menuItemIcon}${prefix}legendasaiu
	${middleBorder}${menuItemIcon}${prefix}limitmessage
	${middleBorder}${menuItemIcon}${prefix}limpar
	${middleBorder}${menuItemIcon}${prefix}limparaluguel
	${middleBorder}${menuItemIcon}${prefix}limpardb
	${middleBorder}${menuItemIcon}${prefix}linkgp
	${middleBorder}${menuItemIcon}${prefix}linkgroup
	${middleBorder}${menuItemIcon}${prefix}listadv
	${middleBorder}${menuItemIcon}${prefix}listblacklist
	${middleBorder}${menuItemIcon}${prefix}listmodcmds
	${middleBorder}${menuItemIcon}${prefix}listmods
	${middleBorder}${menuItemIcon}${prefix}litemode
	${middleBorder}${menuItemIcon}${prefix}marcar
	${middleBorder}${menuItemIcon}${prefix}mark
	${middleBorder}${menuItemIcon}${prefix}modlist
	${middleBorder}${menuItemIcon}${prefix}modobn
	${middleBorder}${menuItemIcon}${prefix}modolite
	${middleBorder}${menuItemIcon}${prefix}modoparceria
	${middleBorder}${menuItemIcon}${prefix}mutar
	${middleBorder}${menuItemIcon}${prefix}mute
	${middleBorder}${menuItemIcon}${prefix}onlyadm
	${middleBorder}${menuItemIcon}${prefix}opengp
	${middleBorder}${menuItemIcon}${prefix}parcerias
	${middleBorder}${menuItemIcon}${prefix}partnerships
	${middleBorder}${menuItemIcon}${prefix}promote
	${middleBorder}${menuItemIcon}${prefix}promover
	${middleBorder}${menuItemIcon}${prefix}rebaixar
	${middleBorder}${menuItemIcon}${prefix}regras
	${middleBorder}${menuItemIcon}${prefix}removeradv
	${middleBorder}${menuItemIcon}${prefix}removerfotobv
	${middleBorder}${menuItemIcon}${prefix}removerfotosaiu
	${middleBorder}${menuItemIcon}${prefix}rentalclean
	${middleBorder}${menuItemIcon}${prefix}revokemodcmd
	${middleBorder}${menuItemIcon}${prefix}rmadv
	${middleBorder}${menuItemIcon}${prefix}rmexitimg
	${middleBorder}${menuItemIcon}${prefix}rmfotobv
	${middleBorder}${menuItemIcon}${prefix}rmfotosaiu
	${middleBorder}${menuItemIcon}${prefix}rmwelcomeimg
	${middleBorder}${menuItemIcon}${prefix}saida
	${middleBorder}${menuItemIcon}${prefix}setdesc
	${middleBorder}${menuItemIcon}${prefix}setdiv
	${middleBorder}${menuItemIcon}${prefix}setname
	${middleBorder}${menuItemIcon}${prefix}soadm
	${middleBorder}${menuItemIcon}${prefix}soadmin
	${middleBorder}${menuItemIcon}${prefix}textbv
	${middleBorder}${menuItemIcon}${prefix}textsaiu
	${middleBorder}${menuItemIcon}${prefix}totag
	${middleBorder}${menuItemIcon}${prefix}unban
	${middleBorder}${menuItemIcon}${prefix}unbangp
	${middleBorder}${menuItemIcon}${prefix}unblacklist
	${middleBorder}${menuItemIcon}${prefix}unblockcmd
	${middleBorder}${menuItemIcon}${prefix}unmute
	${middleBorder}${menuItemIcon}${prefix}welcomeimg
	${middleBorder}${menuItemIcon}${prefix}welcomemsg
	${middleBorder}${menuItemIcon}${prefix}x9
${bottomBorder}
`;
}